#include <stdio.h>
#include "bmp.h"

void changeBmp(PixelArray &p)
{
	for (int i = 0; i < p.rowCount; i++)
		for (int j = 0; j < p.columnCount; j++)
		{
			//if (p.pixels[i][j].red == 255 && p.pixels[i][j].green == 255 && p.pixels[i][j].blue == 255)
				p.pixels[i][j].red = 0;
				p.pixels[i][j].blue = 0;
		}
}

void main()
{
	FILE *f = fopen("d:/files/a/Untitled.bmp", "rb");

	if (!isBmpFile(f))
	{
		printf("Not Bmp File.\n");
		return;
	}

	BmpHeader header;
	readBmpHeader(f, header);
	printBmpHeader(header);

	BmpDib dib;
	readBmpDib(f, dib);
	printBmpDib(dib);

	PixelArray data;
	readBmpPixelArray(f, header, dib, data);

	fclose(f);

	getchar();

	changeBmp(data);

	drawBmp(dib, data);
	releaseBmpPixelArray(data);
}